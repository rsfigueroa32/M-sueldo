# Gestor de Descuentos Salariales

App para calcular tu sueldo real con descuentos.